/*********************************************************************
* File : EmployeeServiceImpl
* Author Name : Suraj Parmar
* Description : This File Is The Bean File Which Contains All The Variables , Their Constructors, Getter Setters , To String.
* Version : 1.0
* Last Modified Date : 31/03/2017
* Change Description : N/A
*********************************************************************/

package com.capgemini.ems.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Employee
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="mygen")
	@SequenceGenerator(name="mygen", sequenceName="hibernate_sequence",initialValue=1)
	private int employee_code;
	
	@NotEmpty(message="Employee Name Cannot Be Empty")
	@Size(max = 40,message="Employee Name Should Not Be More Than 40 Characters Long ")
	private String employee_name;
	
	@NotNull(message="Gender Must be Selected")
	private String employee_gender;
	
	@NotEmpty(message="Designation Must be Selected")
	private String designation_name;
	
	@Pattern(regexp= "[A-Za-z0-9]+@[A-Za-z0-9.-]+[.][A-Za-z]{2,4}", message="Please Enter A Valid Email Address")
	private String employee_email;
	
	@NotEmpty(message="Phone Number Is Mandatory")
	@Size(min = 10, max = 10, message="Phone Number Should Be Exactly 10 Numbers")
	private String  employee_phone;

	public Employee(int employee_code, String employee_name,
			String employee_gender, String designation_name,
			String employee_email, String employee_phone) {
		super();
		this.employee_code = employee_code;
		this.employee_name = employee_name;
		this.employee_gender = employee_gender;
		this.designation_name = designation_name;
		this.employee_email = employee_email;
		this.employee_phone = employee_phone;
	}

	public Employee(String employee_name, String employee_gender,
			String designation_name, String employee_email,
			String employee_phone) {
		super();
		this.employee_name = employee_name;
		this.employee_gender = employee_gender;
		this.designation_name = designation_name;
		this.employee_email = employee_email;
		this.employee_phone = employee_phone;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getEmployee_code() {
		return employee_code;
	}

	public void setEmployee_code(int employee_code) {
		this.employee_code = employee_code;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public String getEmployee_gender() {
		return employee_gender;
	}

	public void setEmployee_gender(String employee_gender) {
		this.employee_gender = employee_gender;
	}

	public String getDesignation_name() {
		return designation_name;
	}

	public void setDesignation_name(String designation_name) {
		this.designation_name = designation_name;
	}

	public String getEmployee_email() {
		return employee_email;
	}

	public void setEmployee_email(String employee_email) {
		this.employee_email = employee_email;
	}

	public String getEmployee_phone() {
		return employee_phone;
	}

	public void setEmployee_phone(String employee_phone) {
		this.employee_phone = employee_phone;
	}

	@Override
	public String toString() {
		return "Employee [employee_code=" + employee_code + ", employee_name="
				+ employee_name + ", employee_gender=" + employee_gender
				+ ", designation_name=" + designation_name
				+ ", employee_email=" + employee_email + ", employee_phone="
				+ employee_phone + "]";
	}
	
	
}
