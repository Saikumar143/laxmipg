/*********************************************************************

* File : Employee Controller
* Author Name : Suraj Parmar
* Description : This controller will forward the requests from one page to another
* Version : 1.0
* Last Modified Date : 31/03/2017
* Change Description : N/A
*********************************************************************/

package com.capgemini.ems.controller;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.capgemini.ems.entities.Employee;
import com.capgemini.ems.service.IEmployeeService;

@Controller
public class EmployeeController
{
	@Autowired
	private IEmployeeService employeeService;

	public EmployeeController(IEmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}

	public EmployeeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IEmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	@RequestMapping("addEmployee")
	public String getAddEmployeePage(Model model)
	{
		List<String> designation = new ArrayList<String>();
		designation.add("--Select--");
		designation.add("Software Engineer");
		designation.add("Senior Software Engineer");
		designation.add("Team Lead");
		designation.add("Manager");
		
		List<String> gender = new ArrayList<>();
		gender.add("Male");
		gender.add("Female");
		
		model.addAttribute("designation",designation);
		model.addAttribute("gender",gender);
		model.addAttribute("employee", new Employee());
		
		return "AddEmployeePage";
		
	}
	
	@RequestMapping(value="processAddEmployee",method=RequestMethod.POST)
	public String processAddEmployee(@ModelAttribute("employee") @Valid Employee employee, BindingResult result, Model model)
	{
		
		if(result.hasErrors() == true)
		{
			List<String> designation = new ArrayList<String>();
			designation.add("Software Engineer");
			designation.add("Senior Software Engineer");
			designation.add("Team Lead");
			designation.add("Manager");
			
			List<String> gender = new ArrayList<>();
			gender.add("Male");
			gender.add("Female");
			
			model.addAttribute("designation",designation);
			model.addAttribute("gender",gender);
			model.addAttribute("employee", employee);
			
			return "AddEmployeePage";
		}
		
		int employee_code = 0 ;
		try
		{
			
			employee_code = employeeService.addEmployee(employee);
		}
		catch(Exception e)
		{	
			model.addAttribute("errMsg", "Something went wrong while adding employee reason " + e.getMessage()) ;
			return "ErrorPage" ;
		}
		
		model.addAttribute("message", "Employee added successfully and employee code is : "+ employee_code ) ;
		return "SuccessPage" ;
			
	}
	
	
	@RequestMapping("showEmployees")
	public String getAllEmployees (Model model)
	{
		List<Employee> eList = new ArrayList<Employee>();
		
		try 
		{
			eList = employeeService.getAllEmployees();
			
		}
		catch (Exception e) 
		{
			model.addAttribute("errMsg", "Could Not Retrieve the list of employees " + e.getMessage()) ;
			return "ErrorPage";
		}
		
		model.addAttribute("eList", eList);
		return "ShowEmployeesPage";
	}
	
	
	
	
	
}
